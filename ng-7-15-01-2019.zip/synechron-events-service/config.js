module.exports = {
    secret: "synechronprvtldt2019q4m1w2"
};