import '@angular/core';
import '@angular/common';
import '@angular/platform-browser';
import '@angular/platform-browser-dynamic';
import '@angular/forms';
import '@angular/router';
import 'rxjs';

//Other third-party libraries
import 'jquery';
import 'popper.js/dist/popper.min';
import 'bootstrap/dist/js/bootstrap';
import 'bootswatch/dist/united/bootstrap.min.css';