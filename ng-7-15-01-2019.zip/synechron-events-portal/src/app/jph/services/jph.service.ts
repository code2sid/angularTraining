import { Injectable } from "@angular/core";

import { CommonHttpCrudRepository } from "../../shared/common-http-crud-repository";

import { Post } from "../models/post";

@Injectable()
export class JphService extends CommonHttpCrudRepository<Post> {
    
}