import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { JphPostsListComponent } from "./jph-posts-list/jph-posts-list.component";


const jphRouteConfig: Routes = [
    {
        path: 'posts',
        component: JphPostsListComponent
    }
];

export const jphRoutes: ModuleWithProviders = RouterModule.forChild(jphRouteConfig);