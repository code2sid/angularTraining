import { Component } from '@angular/core';

import { Employee } from "../models/employee";

@Component({
    selector: 'employees-list',
    templateUrl: 'employees-list.component.html'
})

export class EmployeesListComponent {
    constructor() {
        // this.employee = new Employee();
        // this.employee.employeeId = 23489;
        // this.employee.employeeName = "Pravinkumar R. D.";
        // this.employee.address = "Suncity, A8/404";
        // this.employee.city = "Pune";
        // this.employee.state = "Maharashtra";
        // this.employee.country = "India";
        // this.employee.phone = "+91 23892332";
        // this.employee.email = "dabade.pravinkumar@gmail.com";
        // this.employee.avatar = "images/noimage.png";
    }

    pageTitle: string = "Synechron Employees List!";
    subTitle: string = "Registered employees with Events Portal!";
    employees: Employee[] = [
        {
            employeeId: 23890,
            employeeName: "Manish Kaushik",
            address: "MoonCity, A9/909",
            city: "Pune",
            state: "Maharashtra",
            country: "India",
            phone: "+91 23892833",
            email: "manish.kaushik@synechron.com",
            avatar: "images/noimage.png",
            project: "Microsoft UI"
        },
        {
            employeeId: 23830,
            employeeName: "John Mark",
            address: "e-Street, Wing-5",
            city: "Mumbai",
            state: "Maharashtra",
            country: "India",
            phone: "+91 30004000",
            email: "john.mark@synechron.com",
            avatar: "images/noimage.png",
            project: "Microsoft UI"
        },
        {
            employeeId: 23230,
            employeeName: "Anjala Johns",
            address: "Best Street, A9/909",
            city: "Delhi",
            state: "UP",
            country: "India",
            phone: "+91 20003000",
            email: "anjala.johns@synechron.com",
            avatar: "images/noimage.png",
            project: "Google UI"
        }
    ];
    selectedEmployee: Employee;
    onEmployeeSelection(employee: Employee): void {
        this.selectedEmployee = employee;
        console.log(this.selectedEmployee);
    }
}