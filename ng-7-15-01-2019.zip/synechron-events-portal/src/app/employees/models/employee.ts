export class Employee {
    constructor() {

    }
    employeeId: number;
    employeeName: string;
    address: string;
    city: string;
    state: string;
    country: string;
    phone: string;
    email: string;
    project: string;
    avatar: string;
}