import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";

import { employeesRoutes } from './employees.routes';

import { EmployeesListComponent } from "./employees-list/employees-list.component";
import { EmployeeDetailsComponent } from "./employee-details/employee-details.component";

@NgModule({
    imports: [CommonModule, employeesRoutes],
    exports: [EmployeesListComponent],
    declarations: [EmployeesListComponent, EmployeeDetailsComponent]
})
export class EmployeesModule { }
