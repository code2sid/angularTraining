export class Token {
    constructor() {

    }
    success: boolean;
    role: string;
    token: string;
}