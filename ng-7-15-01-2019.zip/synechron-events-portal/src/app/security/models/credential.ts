export class Credential {
    constructor() {

    }
    userName: string;
    password: string;
}