import { Component, OnInit } from '@angular/core';

import { Event } from "../models/event";

import { EventsService } from "../services/events.service";

@Component({
    selector: 'events-list',
    templateUrl: 'events-list.component.html'
})

export class EventsListComponent implements OnInit {
    constructor(private _eventsService: EventsService) {

    }
    ngOnInit(): void {
        this._eventsService.getAll("http://localhost:9090/api/events").subscribe(
            data => this.events = data,
            err => console.log(err),
            () => console.log("Service call completed!")
        );
    }
    pageTitle: string = "Synechron Events List!";
    subTitle: string = "Events managed by Synechron HR, Pune!";
    //selectedEvent: Event;
    searchChar: string = "";
    events: Event[] = [];
    // onEventSelection(event: Event): void {
    //     this.selectedEvent = event;
    // }
}