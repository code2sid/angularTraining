import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { eventsRoutes } from './events.routes';

import { EventsListComponent } from "./events-list/events-list.component";
import { EventDetailsComponent } from "./event-details/event-details.component";

import { FirstLetterCapitalPipe } from "./pipes/first-letter-capital.pipe";
import { EventsFilterPipe } from "./pipes/events-filter.pipe";

import { EventsService } from "./services/events.service";
import { NewEventComponent } from './new-event/new-event.component';
import { AuthTokenInterceptor } from './services/auth-token.interceptor';
import { AuthService } from './services/auth.service';



@NgModule({
    imports: [CommonModule, FormsModule, HttpClientModule, RouterModule, eventsRoutes, ReactiveFormsModule],
    exports: [EventsListComponent],
    declarations: [
        EventsListComponent,
        EventDetailsComponent,
        NewEventComponent,
        FirstLetterCapitalPipe,
        EventsFilterPipe
    ],
    providers: [
        EventsService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthTokenInterceptor,
            multi: true
        },
        AuthService
    ],
})
export class EventsModule { }
