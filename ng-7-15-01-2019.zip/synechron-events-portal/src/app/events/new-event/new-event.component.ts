import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { EventForm } from "../models/event-form";

import { EventsService } from '../services/events.service';

@Component({
    selector: 'new-event',
    templateUrl: 'new-event.component.html',
    styles:[
        `
            input.ng-invalid { border-left:3px solid red }
            input.ng-valid { border-left:3px solid green }
        `
    ]
})

export class NewEventComponent {
    constructor(private _eventsService: EventsService, private _router: Router) {

    }
    event:EventForm=new EventForm();
    //event: Event = new Event();
    pageTitle: string = "Register New Event!";
    onNewEventSubmit(): void {
        //this.event.logo = "images/noimage.png";
        this._eventsService.addNew(this.event.eventForm.value, "http://localhost:9090/api/events").subscribe(
            data => {
                console.log(data);
                this._router.navigate(["/events"]);
            },
            err => console.log(err),
            () => console.log("Service call completed!")
        );
    }
}