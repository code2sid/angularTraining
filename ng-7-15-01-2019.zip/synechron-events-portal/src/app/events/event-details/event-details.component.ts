import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

import { Event } from '../models/event';

import { EventsService } from '../services/events.service';

@Component({
    selector: 'event-details',
    templateUrl: 'event-details.component.html'
})

export class EventDetailsComponent implements OnInit {
    constructor(private _eventsService: EventsService, private _activatedRoute: ActivatedRoute) { }
    pageTitle: string = "Details of - ";
    //@Input("id") eventId: number;
    event: Event;
    ngOnInit(): void {
        let eventId: any = this._activatedRoute.snapshot.paramMap.get("id");
        this._eventsService.getSingle(eventId, "http://localhost:9090/api/events").subscribe(
            data => this.event = data,
            err => console.log(err),
            () => console.log("Service call completed!")
        );
    }
}