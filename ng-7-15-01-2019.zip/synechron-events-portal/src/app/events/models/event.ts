export class Event {
    constructor() {

    }
    eventId: number;
    eventCode: string;
    eventName: string;
    description: string;
    startDate: Date;
    endDate: Date;
    fees: number;
    attendance: number;
    logo: string;
}