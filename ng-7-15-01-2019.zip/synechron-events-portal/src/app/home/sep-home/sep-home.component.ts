import { Component} from '@angular/core';

@Component({
    selector: 'sep-home',
    templateUrl: 'sep-home.component.html'
})

export class SepHomeComponent {
    constructor() { }
    pageTitle:string="Welcome To Synechron Events Portal Home!";
}