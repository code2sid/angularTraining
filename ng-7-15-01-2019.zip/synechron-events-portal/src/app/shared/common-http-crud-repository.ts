import { CommonHttpCrud } from "./common-http-crud";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class CommonHttpCrudRepository<T> implements CommonHttpCrud<T>{
    constructor(private _httpClient: HttpClient) {

    }
    getAll(url: string): Observable<T[]> {
        return this._httpClient.get<T[]>(url);
    }
    getSingle(id: number, url: string): Observable<T> {
        return this._httpClient.get<T>(`${url}/${id}`);
    }
    addNew(T: T, url: string): Observable<T> {
        return this._httpClient.post<T>(url, T);
    }
}