import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { SepMenuComponent } from './sep-menu/sep-menu.component';


@NgModule({
    imports: [CommonModule,RouterModule],
    exports: [SepMenuComponent],
    declarations: [SepMenuComponent]
})
export class NavigationModule { }
