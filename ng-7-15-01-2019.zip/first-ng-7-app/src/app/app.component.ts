import { Component } from "@angular/core";

@Component({
    selector:"my-app",
    template:"<h1>Welcome To Synechron Pvt. Ltd.1</h1>"
})
export class AppComponent{

}